import React from "react";

const NotFoundPage = () => {
    return (
        <section className="not-found-page">
            <h1>404</h1>
            <h1>Page Not Found</h1>
        </section>
    )
}

export default NotFoundPage;